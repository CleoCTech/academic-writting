<div>
    
     <!--begin::Scrolltop-->
     <div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
        <!--begin::Svg Icon | path: icons/stockholm/Navigation/Up-2.svg-->
        <span class="svg-icon">
            <i class="bi bi-chevron-double-up"></i>
        </span>
        <!--end::Svg Icon-->
    </div>

    <!--end::Scrolltop-->
</div>
<?php /**PATH C:\xampp\htdocs\Nariphon_Technologies\typewriter\resources\views/livewire/admin/inc/scroll-top.blade.php ENDPATH**/ ?>