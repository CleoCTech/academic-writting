<div>
    
    <!-- ============================ Order Start ======================================-->
    <section class="gray-bg">
        <div class="container">
            
            <div class="row">
                <div class="col-12">
                    <div class="_wrap_box_slice">
                        <div class="_job_detail_single">
                            <?php if($varView==""): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.place-order')->html();
} elseif ($_instance->childHasBeenRendered('TwEczY6')) {
    $componentId = $_instance->getRenderedChildComponentId('TwEczY6');
    $componentTag = $_instance->getRenderedChildComponentTagName('TwEczY6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TwEczY6');
} else {
    $response = \Livewire\Livewire::mount('order.place-order');
    $html = $response->html();
    $_instance->logRenderedChild('TwEczY6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <?php elseif($varView=="step2"): ?>
                            <?php elseif($varView=="auth"): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.auth')->html();
} elseif ($_instance->childHasBeenRendered('QJVXTHu')) {
    $componentId = $_instance->getRenderedChildComponentId('QJVXTHu');
    $componentTag = $_instance->getRenderedChildComponentTagName('QJVXTHu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QJVXTHu');
} else {
    $response = \Livewire\Livewire::mount('order.auth');
    $html = $response->html();
    $_instance->logRenderedChild('QJVXTHu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <?php elseif($varView=="success"): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.success')->html();
} elseif ($_instance->childHasBeenRendered('HG1zLkD')) {
    $componentId = $_instance->getRenderedChildComponentId('HG1zLkD');
    $componentTag = $_instance->getRenderedChildComponentTagName('HG1zLkD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HG1zLkD');
} else {
    $response = \Livewire\Livewire::mount('order.success');
    $html = $response->html();
    $_instance->logRenderedChild('HG1zLkD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================ Order End ======================================== -->

</div>
<?php /**PATH C:\xampp\htdocs\Nariphon_Technologies\typewriter\resources\views/livewire/order.blade.php ENDPATH**/ ?>