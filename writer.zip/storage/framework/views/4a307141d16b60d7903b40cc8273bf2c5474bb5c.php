<div>
    
    <!--begin::Toolbar-->
    <?php if($varView ==''): ?>
    <div class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
        <div class="toolbar" id="kt_toolbar">
            <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
                <!--begin::Info-->
                <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                    <!--begin::Title-->
                    <h1 class="text-dark fw-bolder my-1 fs-2">Statements</h1>
                    <!--end::Title-->
                </div>
                <!--end::Info-->
            </div>
        </div>
        <div>
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
        </div>
        <!--end::Toolbar-->
        <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
            <!--begin::Container-->
            <div class="container">
                <!--begin::Row-->

                    <!--end::Row-->
                    <!--begin::Statements-->
                    <div class="card">
                        <!--begin::Header-->
                        <div class="card-header card-header-stretch">
                            <!--begin::Title-->
                            <div class="card-title">
                                <h3 class="fw-bolder fs-2 m-0 text-gray-800">
                                    Statement
                                </h3>
                            </div>
                        </div>
                        <!--end::Header-->
                        <!--begin::Tab Content-->
                        <div id="kt_referred_users_tab_content" class="tab-content">
                            <!--begin::Tab panel-->
                            <div id="kt_referrals_1" class="card-body p-0 tab-pane fade show active" role="tabpanel">
                                <div class="table-responsive">
                                    <!--begin::Table-->
                                    <table class="table table-row-bordered table-flush align-middle gy-4">
                                        <!--begin::Thead-->
                                        <thead
                                            class="border-bottom border-gray-200 fs-5 fw-bold bg-light bg-opacity-75">
                                            <tr>
                                                <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($col['isList'] == true): ?>

                                                <?php if($col['colCaption'] == 'Date'): ?>
                                                <th class="min-w-175px ps-9"><?php echo e($col['colCaption']); ?></th>
                                                <?php elseif($col['colCaption'] == 'Order No'): ?>
                                                <th class="min-w-150px px-0"><?php echo e($col['colCaption']); ?></th>
                                                <?php elseif($col['colCaption'] == 'Details'): ?>
                                                <th class="min-w-350px p-3"><?php echo e($col['colCaption']); ?></th>
                                                <?php elseif($col['colCaption'] == 'Total Amount'): ?>
                                                <th class="min-w-125px"><?php echo e($col['colCaption']); ?></th>
                                                <?php else: ?>
                                                <th class="min-w-125px text-center"><?php echo e($col['colCaption']); ?></th>
                                                <?php endif; ?>

                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <th class="min-w-125px text-start">Invoice</th>
                                            </tr>
                                        </thead>
                                        <!--end::Thead-->
                                        <!--begin::Tbody-->
                                        <tbody class="fs-5 fw-bold text-gray-600">
                                            <?php if(count($data) > 0): ?>

                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($col['isList'] == true): ?>

                                                        <?php if(isset($col['isRelationship']) && $col['isRelationship'] == true): ?>
                                                            <?php if($col['colCaption'] == 'Date'): ?>
                                                                <td class="ps-9">
                                                                    <?php echo date('d/M/y', strtotime($record[$col['relName']][$col['colName']])); ?>

                                                                    
                                                                </td>
                                                            <?php elseif($col['colCaption'] == 'Order No'): ?>
                                                                <td class="ps-0">
                                                                    <?php echo e($record[$col['relName']][$col['colName']]); ?>

                                                                </td>
                                                            <?php elseif($col['colCaption'] == 'Total Amount'): ?>
                                                                <td class="text-success text-center">
                                                                    <?php echo e($record[$col['relName']][$col['colName']]); ?>

                                                                </td>
                                                            <?php elseif($col['colCaption'] == 'Details'): ?>
                                                                <td class = "d-flex flex-column align-items-start text-start p-3">
                                                                    <?php echo e($record[$col['relName']][$col['colName']]); ?>

                                                                    <span class="text-muted text-xs italic">
                                                                        <?php echo e(strlen($record[$col['relName']]['instructions']) > 100? substr($record[$col['relName']]['instructions'],0,100).'...':$record[$col['relName']]['instructions']); ?>

                                                                    </span>
                                                                </td>
                                                            <?php else: ?>
                                                                <td>
                                                                    <?php echo e($record[$col['relName']][$col['colName']]); ?>

                                                                </td>

                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php if($col['colCaption'] == 'Date'): ?>
                                                                <td class="ps-9">
                                                                    <?php echo date('d/M/y', strtotime($record[$col['colName']])); ?>

                                                                    
                                                                </td>
                                                            <?php elseif($col['colCaption'] == 'Order No'): ?>
                                                                <td class="ps-0">
                                                                    <?php echo e($record[$col['colName']]); ?>

                                                                </td>
                                                            <?php elseif($col['colCaption'] == 'Total Amount'): ?>
                                                                <?php echo e($this->checkPaidStatus($record[$keyCol])); ?>

                                                                
                                                                <?php if($paidStatus): ?>
                                                                <td class="text-success ">
                                                                    $<?php echo e($this->checkBalance($record[$keyCol])); ?>

                                                                </td>
                                                                <?php else: ?>
                                                                <td class="text-danger ">
                                                                   $ -<?php echo e($this->checkBalance($record[$keyCol])); ?>

                                                                </td>
                                                                <?php endif; ?>


                                                            <?php else: ?>
                                                                <td>
                                                                    <?php echo e($record[$col['colName']]); ?>

                                                                </td>

                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="text-start">
                                                        <?php if(auth()->guard()->guest()): ?>
                                                        <button wire:click="checkOrder(<?php echo e($record[$keyCol]); ?>)" class="btn btn-sm btn-light btn-active-light-primary" <?php echo e($paidStatus? 'disabled':''); ?>>
                                                            Pay
                                                        </button>
                                                        <?php endif; ?>
                                                        <?php if(auth()->guard()->check()): ?>
                                                        <button class="btn btn-sm btn-light btn-active-light-primary" <?php echo e($paidStatus? 'disabled':''); ?>>
                                                            Request Payment
                                                        </button>
                                                        <?php endif; ?>

                                                        <span>
                                                            <button class="btn btn-sm btn-light btn-active-light-primary">
                                                                View
                                                            </button>
                                                        </span>
                                                        <span>
                                                            <button class="btn btn-sm btn-light btn-active-light-primary">
                                                                Download
                                                            </button>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php else: ?>
                                            <tr>
                                                <td class="italic text-center" colspan="<?php echo e(count($cols)); ?>"><br>*** No records
                                                    found ***</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                        <!--end::Tbody-->
                                    </table>
                                    <!--end::Table-->
                                </div>
                            </div>
                        </div>
                        <!--end::Tab Content-->
                    </div>
                    <!--end::Statements-->
                </div>
                <!--end::Container-->
            </div>
        </div>
    </div>
    <?php elseif($varView == 'check-order'): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.check-order')->html();
} elseif ($_instance->childHasBeenRendered('2yVw2mf')) {
    $componentId = $_instance->getRenderedChildComponentId('2yVw2mf');
    $componentTag = $_instance->getRenderedChildComponentTagName('2yVw2mf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2yVw2mf');
} else {
    $response = \Livewire\Livewire::mount('order.check-order');
    $html = $response->html();
    $_instance->logRenderedChild('2yVw2mf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php elseif($varView == 'checkout'): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.billing')->html();
} elseif ($_instance->childHasBeenRendered('75omSib')) {
    $componentId = $_instance->getRenderedChildComponentId('75omSib');
    $componentTag = $_instance->getRenderedChildComponentTagName('75omSib');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('75omSib');
} else {
    $response = \Livewire\Livewire::mount('order.billing');
    $html = $response->html();
    $_instance->logRenderedChild('75omSib', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Nariphon_Technologies\typewriter\resources\views/livewire/client/invoice.blade.php ENDPATH**/ ?>