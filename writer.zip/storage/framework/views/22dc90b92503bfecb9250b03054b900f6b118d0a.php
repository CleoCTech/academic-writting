<div>
    
    <fieldset>
        <div class="form-card">
            <h2 class="fs-title text-center h2">Success !</h2>
            <br /><br />
            <div class="row justify-content-center">
                <div class="col-3">
                    <img src="https://img.icons8.com/color/96/000000/ok--v2.png"
                        class="fit-image" />
                </div>
            </div>
            <br /><br />
            <div class="row justify-content-center">
                <div class="col-7 text-center">
                    <h5 class="h5">
                        Order Submitted Successfully. 
                    </h5>
                </div>
            </div>
        </div>
    </fieldset>
</div>
<?php /**PATH C:\xampp\htdocs\Nariphon_Technologies\typewriter\resources\views/livewire/order/success.blade.php ENDPATH**/ ?>