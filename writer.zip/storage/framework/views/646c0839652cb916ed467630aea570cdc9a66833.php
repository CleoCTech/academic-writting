<div>
    

<div  class="content fs-6 d-flex flex-column flex-column-fluid" id="kt_content">
     <!--begin::Toolbar-->
     <div class="toolbar" id="kt_toolbar">
        <div class="container-fluid d-flex flex-stack flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex flex-column align-items-start justify-content-center flex-wrap me-2">
                <!--begin::Title-->
                <h1 class="text-dark fw-bolder my-1 fs-2">
                    Paper Details
                    <small class="text-muted fs-6 fw-normal ms-1"></small>
                </h1>

                <!--end::Title-->
            </div>
            <!--end::Info-->
            <!--begin::Actions-->
            <div class="d-flex align-items-center flex-nowrap text-nowrap py-1">
                <a class="btn btn-primary" id="kt_toolbar_primary_button" wire:click='back'><span
                        class="svg-icon svg-icon-2 rotate-180"> <i class="bi bi-arrow-bar-left"></i> </span>Back</a>
            </div>
            <!--end::Actions-->
        </div>
    </div>
    <div>
        <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
        <?php elseif(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="post fs-6 d-flex flex-column-fluid" id="kt_post">
        <div class="container">
            <fieldset class="proposal-form">
                <div>
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('message')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <div class="form-group">
                            <label>Number of Pages</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">@</span>
                                </div>
                                <input type="number" class="form-control" wire:model.defer="pages" value=''/><?php $__errorArgs = ['pages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span
                                    class="error" style="color:red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="form-group">
                            <label>Deadline</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Date</span>
                                </div>
                                <input type="date" class="form-control" wire:model.defer='deadline_date' /><?php $__errorArgs = ['deadline_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error" style="color:red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="form-group">
                            <label>Time</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Time</span>
                                </div>
                                <input type="time" class="form-control" wire:model.defer='deadline_time' /><?php $__errorArgs = ['deadline_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error" style="color:red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <div class="form-group">
                            <label>Select your Subject</label>
                            <select class="form-control" wire:model.defer="category_id">
                                <option disabled selected>Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->subject); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error" style="color:red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <div class="form-group">
                            <label>What is your topic?</label>
                            <input type="text" class="form-control" wire:model.defer="topic" /><?php $__errorArgs = ['topic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"
                                style="color:red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="form-group">
                            
                            <label>Paper Instructions</label>
                            <textarea class="form-control" rows="3" id="body"
                                wire:model.defer="instructions"></textarea><?php $__errorArgs = ['instructions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"
                                style="color:red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $clientFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clientFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">

                    <div class="col-md-4">
                        <a class="text-gray-600 text-hover-primary fw-bold fs-6 mb-3 "><?php echo e($clientFile->filename); ?>

                            <span>
                                <a  wire:click="dropFile('<?php echo e($clientFile->folder); ?>')"
                                    type="button" class="btn-floating btn-small "> <span
                                        class="svg-icon svg-icon-3">
                                        <a href="#" wire:click="dropFile('<?php echo e($clientFile->folder); ?>', '<?php echo e($clientFile->filename); ?>')" class="text-gray-600 text-hover-danger fw-bold fs-6 mb-3" ><i class="bi bi-x-circle"></i></a>

                                </span></a>
                            </span>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h4 class="text-blue-400 " style="margin-top: 1rem;">Add Files (Optional)
                    <span
                        class="svg-icon svg-icon-4 ">
                        <i class="bi bi-paperclip text-blue-400"></i>
                    </span>
                  </h4>
                <div wire:ignore class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <input type="file" name="paperFile" id="test" multiple>
                    </div>
                    <script type="text/javascript">
                        const inputElement = document.querySelector('input[id="test"]');
                        const pond = FilePond.create( inputElement );
                        FilePond.setOptions({
                            server:{
                                url: '/upload',
                                headers: {
                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                }
                            }
                        });
                    </script>
                </div>
                <hr>
                <br>
                <div class="btn-group text-center" role="group" aria-label="Basic example" style='display: block;'>
                    <a class="btn btn-primary" id="kt_toolbar_primary_button" wire:click='store'><span
                        class="svg-icon svg-icon-2 rotate-180"> </span>Submit <i class="bi bi-arrow-bar-right"></i></a>

                </div>
            </fieldset>
        </div>
    </div>

</div>
</div>
<style>


    .btn-floating i:hover{
       color: #84a8f0;
       size: 2rem;
        /* color: #fff; */
    }

</style>
<?php /**PATH C:\xampp\htdocs\Nariphon_Technologies\typewriter\resources\views/livewire/client/edit-order.blade.php ENDPATH**/ ?>