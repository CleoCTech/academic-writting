<div>
    
     <!-- =========================== Footer Start ========================================= -->
     <footer class="dark-footer skin-dark-footer">
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-widget">
                            <img src="assets/img/logo.png" class="img-fluid f-logo" width="120" alt="" />
                            <p>407-00100 GPO, Nairobi<br />Kenya</p>
                            <ul class="footer-bottom-social">
                                <li>
                                    <a href="#"><i class="ti-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="ti-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="ti-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="ti-linkedin"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-4">
                        <div class="footer-widget">
                            <h4 class="widget-title">Services</h4>
                            <ul class="footer-menu">
                                <li><a href="#">Order Essay</a></li>
                                <li><a href="#">Buy Essay</a></li>
                                <li><a href="#">Assigments</a></li>
                                <li><a href="#">For Writers</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-4">
                        <div class="footer-widget">
                            <h4 class="widget-title">Pages</h4>
                            <ul class="footer-menu">
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">How it Works</a></li>
                                <li><a href="#">FAQ</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-4">
                        <div class="footer-widget">
                            <h4 class="widget-title">Support</h4>
                            <ul class="footer-menu">
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Privacy &amp; Terms</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12 col-md-12 text-center">
                        <p class="mb-0">
                            © 2021 TypeWriter. Made with 💖 in
                            <a href="#">Chuka.</a> All Rights Reserved
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- =========================== Footer End ========================================= -->
</div>
<?php /**PATH C:\xampp\htdocs\Nariphon_Technologies\typewriter\resources\views/livewire/inc/footer.blade.php ENDPATH**/ ?>