-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 06, 2021 at 04:36 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nariphon_writer`
--

-- --------------------------------------------------------

--
-- Table structure for table `accepted_orders`
--

CREATE TABLE `accepted_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_id` bigint(20) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Committed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accepted_orders`
--

INSERT INTO `accepted_orders` (`id`, `order_id`, `comment`, `from`, `from_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 24, 'Accepted', 'client', 17, 'Committed', '2021-06-01 12:45:42', '2021-06-01 12:45:42');

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
  `from_id` bigint(20) DEFAULT NULL,
  `to_id` bigint(20) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `name`, `value`, `status`, `from_id`, `to_id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Sent Invoice', '50', 'responded', 1, 14, 'Admin', '2021-05-23 07:40:26', '2021-05-23 07:40:26'),
(2, 'Sent Invoice', '25', 'responded', 1, 14, 'Admin', '2021-05-23 11:44:40', '2021-05-23 11:44:40'),
(3, 'Sent Invoice', '60', 'responded', 1, 14, 'Admin', '2021-05-23 11:49:54', '2021-05-23 11:53:26'),
(4, 'Sent Invoice', '10', 'responded', 1, 14, 'Admin', '2021-05-23 12:02:23', '2021-05-23 12:02:30'),
(5, 'Sent Invoice', '16', 'responded', 1, 14, 'Admin', '2021-05-23 12:05:16', '2021-05-23 12:05:20'),
(6, 'Sent Invoice', '20', 'responded', 1, 14, 'Admin', '2021-05-23 12:28:21', '2021-05-23 12:28:26'),
(7, 'Sent Invoice', '10', 'responded', 1, 14, 'Admin', '2021-05-23 12:42:21', '2021-05-23 12:42:35'),
(8, 'Sent Invoice', '20', 'responded', 1, 18, 'Admin', '2021-05-25 22:53:36', '2021-05-25 22:56:00'),
(9, 'Sent Invoice', '20', 'responded', 1, 17, 'Admin', '2021-05-30 19:49:54', '2021-05-30 19:50:08'),
(10, 'Sent Invoice', '20', 'responded', 1, 17, 'Admin', '2021-06-01 10:19:29', '2021-06-01 10:19:39');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `email`, `username`, `password`, `email_verified_at`, `created_at`, `updated_at`) VALUES
(1, 'fekisyka@mailinator.com', 'Sit rerum omnis con', '$2y$10$sxQ6Gw9.YXUWdZNbTZuuiOzCRbEKFXGi8UM2CJkOj5oglqyTZ9ije', '2021-05-15 10:45:33', '2021-05-12 15:38:03', '2021-05-12 15:38:03'),
(2, 'wemur@mailinator.com', 'Eaque doloribus quas', '$2y$10$/Mehcg.Hsek.N2NsYvguYOT6y2aNw4gDNh2K4WdDNZrz0rZxkvzxm', NULL, '2021-05-14 05:21:52', '2021-05-14 05:21:52'),
(3, 'hyfegy@mailinator.com', 'Ex in provident bea', '$2y$10$r.vV3s5v1oTVuoBXpzaT8efLfhGItF.WLdDdKmPblnwkKqwlu7yim', NULL, '2021-05-14 05:26:01', '2021-05-14 05:26:01'),
(4, 'faloh@mailinator.com', 'Corporis ipsum fugi', '$2y$10$u4Pd9wtB70z3529X6TLpBOewQma9BcFvLcQjvZwAzuHEZMOv2EddC', NULL, '2021-05-14 05:33:03', '2021-05-14 05:33:03'),
(5, 'kanap@mailinator.com', 'Modi at quia rerum b', '$2y$10$oU7b3LcIqScBKYLCxhwnG.sPo50l7lnbb8HlPLVjzDzZSV.Nd3qiC', NULL, '2021-05-14 13:12:21', '2021-05-14 13:12:21'),
(6, 'suciqicege@mailinator.com', 'Harum voluptas praes', '$2y$10$rakToW70i2xBtAeDNirgaubzCBG0QJcPR.js6/uOmP0jxhg9cYJem', NULL, '2021-05-14 14:08:29', '2021-05-14 14:08:29'),
(7, 'mopiqy@mailinator.com', 'Numquam dolorem face', '$2y$10$Zlm.DM6GXDWQ55tSnnZBluXf0Wvfl8Q5YucqT3Zc.UbkppPrI/GH.', NULL, '2021-05-14 14:23:53', '2021-05-14 14:23:53'),
(8, 'gyxeha@mailinator.com', 'Officiis ut sunt ve', '$2y$10$UuTo.MCXEdEIqJ7m0QxXc.bVU5FdcLG5XkDgJIkJGAigmF8GIcTqi', NULL, '2021-05-14 14:40:50', '2021-05-14 14:40:50'),
(9, 'qoxekun@mailinator.com', 'Ad minus reprehender', '$2y$10$e1nbJdHPxXAGKWeAwjtXbuAJf0jJcqrfMV54fkUqF0rINrMl1tgRS', NULL, '2021-05-14 14:48:52', '2021-05-14 14:48:52'),
(10, 'tevosukyb@mailinator.com', 'Commodo nihil praese', '$2y$10$NvA2t2xlqrmEnUUmI36rPu3ZTVy6F/oJJR2I60l0/gRc7PDfPdYfC', NULL, '2021-05-14 15:21:40', '2021-05-14 15:21:40'),
(11, 'byraxi@mailinator.com', 'Ea natus ut hic veli', '$2y$10$WF71h8mhij7E9H87RLC/je0VLV3sMc4TD1.6mVa4zT.d7iEsS8n7G', NULL, '2021-05-14 15:38:18', '2021-05-14 15:38:18'),
(12, 'haliz@mailinator.com', 'Modi incididunt obca', '$2y$10$GyAEtGKoFHJmPqgCeo0wWukPuf8yOf0oVMp6AaNSYIeeUHiPB5KCC', NULL, '2021-05-14 15:44:55', '2021-05-14 15:44:55'),
(13, 'kyqu@mailinator.com', 'Accusamus eum in ea ', '$2y$10$qka8yvuTCaUXnl9W2jLNUe37sZntjvHDFbI/6WqBokIsQ7RZazXfC', NULL, '2021-05-14 15:49:24', '2021-05-14 15:49:24'),
(14, 'cleoctech@gmail.com', 'Cleophas Omwenga', '$2y$10$Xm03/ckW6HGiAI/dO0MKZO3NI.Uy5N3/7kk6n2HHjKxpjAo0TuaMi', NULL, '2021-05-15 07:57:59', '2021-05-15 07:57:59'),
(15, 'jayden@gmail.com', 'Jayden Uhuru', '$2y$10$yka3/1klmfwlDigSi82tmOEB2TUPegCAnE7M.6fyg1DfoX5zwVZOO', NULL, '2021-05-21 22:18:12', '2021-05-21 22:18:12'),
(16, 'emilyshan@gmail.com', 'Emily Shan', '$2y$10$W89AE971SQwSbGS7.Aiy7O7PTKNDIDy1GQhxpQsdJDVFPutSc7MiO', NULL, '2021-05-23 16:44:12', '2021-05-23 16:44:12'),
(17, 'eastherkm@gmail.com', 'Easther Kome', '$2y$10$mgMJaOkM8m4xXfNsn1ZHjOSqf9Wi909JuneLK6Bni9P91do6wvbi6', NULL, '2021-05-25 22:11:20', '2021-05-25 22:11:20'),
(18, 'emilyopore@gmail.com', 'Emily Opore', '$2y$10$LSiodMBuMQ8MkqiIJcAhNuPk5RIwATiyJvOzwvapiQhwcDj.YdXVC', NULL, '2021-05-25 22:44:19', '2021-05-25 22:44:19'),
(19, 'kaleka@gmail.com', 'Yvonne Kaleka', '$2y$10$udyerd9ccbIrI/TKJzM//Om2ftWGu5LWqm1bBWrjJyP21IE7hlocu', NULL, '2021-06-01 22:23:00', '2021-06-01 22:23:00'),
(20, 'babu@gmail.com', 'John Babu', '$2y$10$TYi3TXV.flBZPMkG.p1q1ufmnnjogk8AcaYrc5l9uxz0cnyueIqsq', NULL, '2021-06-01 22:36:03', '2021-06-01 22:36:03'),
(21, 'momanyiongware@gmail.com', 'Amos Maranga Atima', '$2y$10$38jEAy5PNlXmbmwG/S2G0O3VwKOfleFV/pRHMMYJoFVIVC3iQ6RKi', NULL, '2021-06-01 23:40:42', '2021-06-01 23:40:42');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `size`, `manipulations`, `custom_properties`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\ClientFile', 7, 'client_files', 'WhatsApp Image 2021-04-13 at 22.00.02', 'WhatsApp-Image-2021-04-13-at-22.00.02.PNG', 'image/jpeg', 'public', 84977, '[]', '[]', '[]', 1, '2021-05-14 15:49:25', '2021-05-14 15:49:25'),
(2, 'App\\Models\\ClientFile', 8, 'client_files', 'April-June Session  Announcement.12.4.2021', 'April-June-Session--Announcement.12.4.2021.pdf', 'application/pdf', 'public', 227997, '[]', '[]', '[]', 2, '2021-05-14 15:49:25', '2021-05-14 15:49:25'),
(3, 'App\\Models\\ClientFile', 9, 'client_files', 'Post', 'Post.php', 'text/x-php', 'public', 7093, '[]', '[]', '[]', 3, '2021-05-15 07:58:00', '2021-05-15 07:58:00'),
(4, 'App\\Models\\ClientFile', 10, 'client_files', 'triangle', 'triangle.txt', 'text/plain', 'public', 1244, '[]', '[]', '[]', 4, '2021-05-18 22:21:54', '2021-05-18 22:21:54'),
(5, 'App\\Models\\ClientFile', 11, 'client_files', 'Object-Oriented Analysis, Design and Implementation An Integrated Approach by Brahma Dathan, Sarnath[1073] (1)', 'Object-Oriented-Analysis,-Design-and-Implementation-An-Integrated-Approach-by-Brahma-Dathan,-Sarnath[1073]-(1).pdf', 'application/pdf', 'public', 4556493, '[]', '[]', '[]', 5, '2021-05-18 22:21:55', '2021-05-18 22:21:55'),
(6, 'App\\Models\\ClientFile', 12, 'client_files', 'btree', 'btree.pdf', 'application/pdf', 'public', 1844164, '[]', '[]', '[]', 6, '2021-05-18 23:17:08', '2021-05-18 23:17:08'),
(7, 'App\\Models\\ClientFile', 13, 'client_files', 'Object-Oriented Analysis, Design and Implementation An Integrated Approach by Brahma Dathan, Sarnath[1073] (1)', 'Object-Oriented-Analysis,-Design-and-Implementation-An-Integrated-Approach-by-Brahma-Dathan,-Sarnath[1073]-(1).pdf', 'application/pdf', 'public', 4556493, '[]', '[]', '[]', 7, '2021-05-18 23:17:09', '2021-05-18 23:17:09'),
(8, 'App\\Models\\ClientFile', 14, 'client_files', 'triangle', 'triangle.txt', 'text/plain', 'public', 1244, '[]', '[]', '[]', 8, '2021-05-21 22:18:13', '2021-05-21 22:18:13'),
(9, 'App\\Models\\ClientFile', 15, 'client_files', 'cw1 (2)', 'cw1-(2).pdf', 'application/pdf', 'public', 182423, '[]', '[]', '[]', 9, '2021-05-21 22:18:14', '2021-05-21 22:18:14'),
(10, 'App\\Models\\ClientFile', 16, 'client_files', 'IMG-20210521-WA0000', 'IMG-20210521-WA0000.jpg', 'image/jpeg', 'public', 133972, '[]', '[]', '[]', 10, '2021-05-23 16:44:13', '2021-05-23 16:44:13'),
(11, 'App\\Models\\ClientFile', 17, 'client_files', 'cw1 (2)', 'cw1-(2).pdf', 'application/pdf', 'public', 182423, '[]', '[]', '[]', 11, '2021-05-23 16:44:14', '2021-05-23 16:44:14');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_id` bigint(20) NOT NULL,
  `to_id` bigint(20) DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `message`, `from_id`, `to_id`, `type`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 'Hi, ', 14, 1, 'Client', 0, '2021-05-20 13:50:21', '2021-05-20 13:50:23'),
(2, 'Hello, We are sending an invoice for your order in a few. Thank you. ', 1, 14, 'Admin', 0, '2021-05-20 13:51:56', '2021-05-20 13:51:58'),
(3, 'Okay, I will be waiting...', 14, 1, 'Client', 0, '2021-05-21 03:24:04', '2021-05-21 03:24:06'),
(4, 'Sir, we will charge you $20 for this task...', 1, 14, 'Admin', 0, '2021-05-21 03:26:30', '2021-05-21 03:26:31'),
(5, 'Hey New Client', 1, 1, 'Client', 0, '2021-05-21 11:59:01', '2021-05-21 11:59:03'),
(6, 'Yes', 1, 1, 'Admin', 0, '2021-05-21 12:06:39', '2021-05-21 12:06:42'),
(7, 'Are you there?', 1, 14, 'Admin', 0, '2021-05-21 16:19:06', '2021-05-21 16:19:06'),
(8, 'Are you there?', 1, 14, 'Admin', 0, '2021-05-21 16:28:35', '2021-05-21 16:28:35'),
(9, 'dope..', 1, 14, 'Admin', 0, '2021-05-21 16:31:16', '2021-05-21 16:31:16'),
(10, 'You will get a confirmation notification  for your invoice, kindly confirm', 1, 14, 'Admin', 0, '2021-05-21 16:32:08', '2021-05-21 16:32:08'),
(11, 'hmm\n', 1, 14, 'Admin', 0, '2021-05-21 16:40:21', '2021-05-21 16:40:21'),
(12, 'okay', 1, 14, 'Admin', 0, '2021-05-21 16:41:16', '2021-05-21 16:41:16'),
(13, 'hello,', 1, 14, 'Admin', 0, '2021-05-21 16:53:22', '2021-05-21 16:53:22'),
(14, 'Heey', 1, 14, 'Admin', 0, '2021-05-21 17:12:41', '2021-05-21 17:12:41'),
(15, 'hello', 14, 1, 'Client', 0, '2021-05-21 21:54:17', '2021-05-21 21:54:17'),
(16, 'I was help up, sorry...', 14, 1, 'Client', 0, '2021-05-21 21:54:38', '2021-05-21 21:54:38'),
(17, 'Okay Okay', 1, 14, 'Admin', 0, '2021-05-21 21:56:02', '2021-05-21 21:56:02'),
(18, 'Hi', 15, 1, 'Client', 0, '2021-05-21 22:19:25', '2021-05-21 22:19:25'),
(19, 'Yes, We are going through your document...in a few', 1, 15, 'Admin', 0, '2021-05-21 22:20:59', '2021-05-21 22:20:59'),
(20, 'Okay?', 1, 15, 'Admin', 0, '2021-05-21 22:22:47', '2021-05-21 22:22:47'),
(21, 'yes', 15, 1, 'Client', 0, '2021-05-21 22:23:08', '2021-05-21 22:23:08'),
(22, 'Sawa', 15, 1, 'Client', 0, '2021-05-21 22:35:05', '2021-05-21 22:35:05'),
(23, 'Yeah Yeah', 1, 15, 'Admin', 0, '2021-05-21 22:35:27', '2021-05-21 22:35:27'),
(24, 'I\'m about to confirm invoice\n', 14, 1, 'Client', 0, '2021-05-23 08:29:33', '2021-05-23 08:29:33'),
(25, 'For order order_60a40466c41d9 will charge you $10 per page', 1, 14, 'Admin', 0, '2021-05-23 12:41:10', '2021-05-23 12:41:10'),
(26, 'okay', 14, 1, 'Client', 0, '2021-05-23 12:42:05', '2021-05-23 12:42:05'),
(27, 'Hey', 14, 1, 'Client', 0, '2021-05-24 09:03:40', '2021-05-24 09:03:40'),
(28, 'okay', 14, 1, 'Client', 0, '2021-05-24 09:04:00', '2021-05-24 09:04:00'),
(29, 'hey', 14, 1, 'Client', 0, '2021-05-24 09:16:11', '2021-05-24 09:16:11'),
(30, 'hhhh', 14, 1, 'Client', 0, '2021-05-24 09:18:18', '2021-05-24 09:18:18'),
(31, 'hey hey', 14, 1, 'Client', 0, '2021-05-24 09:20:30', '2021-05-24 09:20:30'),
(32, 'hi', 14, 1, 'Client', 0, '2021-05-24 09:34:37', '2021-05-24 09:34:37'),
(33, 'heyy', 14, 1, 'Client', 0, '2021-05-24 09:34:50', '2021-05-24 09:34:50'),
(34, 'hello', 14, 1, 'Client', 0, '2021-05-24 22:54:33', '2021-05-24 22:54:33'),
(35, 'here now', 14, 1, 'Client', 0, '2021-05-24 22:54:59', '2021-05-24 22:54:59'),
(36, 'Hi', 14, 1, 'Client', 0, '2021-05-24 23:10:11', '2021-05-24 23:10:11'),
(37, 'hi', 14, 1, 'Client', 0, '2021-05-24 23:10:26', '2021-05-24 23:10:26'),
(38, 'Test1', 14, 1, 'Client', 0, '2021-05-24 23:13:48', '2021-05-24 23:13:48'),
(39, 'dfgef', 14, 1, 'Client', 0, '2021-05-24 23:18:54', '2021-05-24 23:18:54'),
(40, 'edrsgrte', 14, 1, 'Client', 0, '2021-05-24 23:19:11', '2021-05-24 23:19:11'),
(41, 'dshr', 14, 1, 'Client', 0, '2021-05-24 23:20:28', '2021-05-24 23:20:28'),
(42, 'hello', 14, 1, 'Client', 0, '2021-05-24 23:20:54', '2021-05-24 23:20:54'),
(43, 'yoh', 14, 1, 'Client', 0, '2021-05-24 23:23:29', '2021-05-24 23:23:29'),
(44, 'sr', 14, 1, 'Client', 0, '2021-05-24 23:24:59', '2021-05-24 23:24:59'),
(45, 'jjj', 14, 1, 'Client', 0, '2021-05-24 23:26:07', '2021-05-24 23:26:07'),
(46, 'jj', 14, 1, 'Client', 0, '2021-05-24 23:26:17', '2021-05-24 23:26:17'),
(47, 'uuu', 14, 1, 'Client', 0, '2021-05-24 23:26:27', '2021-05-24 23:26:27'),
(48, 'Yes', 1, 14, 'Admin', 0, '2021-05-25 03:41:17', '2021-05-25 03:41:17'),
(49, 'Hi', 17, 1, 'Client', 0, '2021-05-25 22:12:20', '2021-05-25 22:12:20'),
(50, 'Hello, ', 1, 17, 'Admin', 0, '2021-05-25 22:14:20', '2021-05-25 22:14:20'),
(51, 'Hi', 18, 1, 'Client', 0, '2021-05-25 22:46:27', '2021-05-25 22:46:27'),
(52, 'Yes', 1, 18, 'Admin', 0, '2021-05-25 22:50:50', '2021-05-25 22:50:50'),
(53, 'I\'m sending you an invoice please confirm...', 1, 18, 'Admin', 0, '2021-05-25 22:51:29', '2021-05-25 22:51:29'),
(54, 'We will charge $20 per page', 1, 18, 'Admin', 0, '2021-05-25 22:52:25', '2021-05-25 22:52:25'),
(55, 'Okay no problem', 18, 1, 'Client', 0, '2021-05-25 22:52:46', '2021-05-25 22:52:46'),
(56, 'hi', 14, 1, 'Client', 0, '2021-05-26 18:21:49', '2021-05-26 18:21:49'),
(57, 'Hi', 17, 1, 'Client', 0, '2021-05-30 19:49:17', '2021-05-30 19:49:17'),
(58, 'Yes', 1, 17, 'Admin', 0, '2021-05-30 19:49:31', '2021-05-30 19:49:31'),
(59, 'Hi', 17, 1, 'Client', 0, '2021-06-01 10:17:27', '2021-06-01 10:17:27'),
(60, 'Yes, Kome  we will charge you $20 per page', 1, 17, 'Admin', 0, '2021-06-01 10:18:52', '2021-06-01 10:18:52'),
(61, 'okay', 17, 1, 'Client', 0, '2021-06-01 10:19:04', '2021-06-01 10:19:04');

-- --------------------------------------------------------

--
-- Table structure for table `message_tos`
--

CREATE TABLE `message_tos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message_id` bigint(20) UNSIGNED DEFAULT NULL,
  `to_id` bigint(20) NOT NULL,
  `to_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `message_tos`
--

INSERT INTO `message_tos` (`id`, `message_id`, `to_id`, `to_type`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Admin', 0, '2021-05-20 13:50:45', '2021-05-20 13:50:48'),
(2, 2, 14, 'Client', 0, '2021-05-20 13:52:42', '2021-05-20 13:52:44'),
(3, 3, 1, 'Admin', 0, '2021-05-21 03:25:19', '2021-05-21 03:25:22'),
(4, 4, 14, 'Client', 0, '2021-05-21 03:27:57', '2021-05-21 03:27:59');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2020_05_21_100000_create_teams_table', 1),
(7, '2020_05_21_200000_create_team_user_table', 1),
(8, '2020_05_21_300000_create_team_invitations_table', 1),
(9, '2021_04_23_072914_create_sessions_table', 1),
(10, '2021_05_08_202810_create_paper_categories_table', 2),
(11, '2021_05_08_203718_create_clients_table', 2),
(12, '2021_05_08_204447_create_orders_table', 2),
(13, '2021_05_10_211040_create_temporary_files_table', 3),
(14, '2021_05_13_232644_create_client_files_table', 4),
(15, '2021_05_13_234956_create_media_table', 4),
(16, '2021_05_17_000550_create_messages_table', 5),
(17, '2021_05_20_043311_create_message_tos_table', 5),
(18, '2021_05_23_020357_create_activities_table', 6),
(19, '2021_05_23_050001_create_order_billings_table', 7),
(20, '2021_05_27_220828_add_from_to_client_files_table', 8),
(21, '2021_05_31_041535_create_rejected_orders_table', 9),
(22, '2021_06_01_055618_create_accepted_orders_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `topic` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pages` int(11) NOT NULL,
  `deadline_date` date NOT NULL,
  `deadline_time` time NOT NULL,
  `instructions` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('In progress','Pending','Done','Complete','Rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_no`, `client_id`, `subject_id`, `topic`, `pages`, `deadline_date`, `deadline_time`, `instructions`, `status`, `created_at`, `updated_at`) VALUES
(2, 'order_609e3e0421b99', 4, 3, 'Excepturi vero totam', 79, '1971-10-07', '01:01:00', 'Nulla sunt nostrud s', 'In progress', '2021-05-14 14:08:29', '2021-05-14 14:08:29'),
(3, 'order_609e41a06bcb0', 7, 1, 'In aliquip earum nul', 31, '1983-02-20', '09:52:00', 'Temporibus modi volu', 'In progress', '2021-05-14 14:23:53', '2021-05-14 14:23:53'),
(4, 'order_609e4597bd59a', 8, 2, 'Voluptate dolor dolo', 58, '2002-04-02', '21:53:00', 'Voluptas minim dolor', 'Complete', '2021-05-14 14:40:50', '2021-05-14 14:40:50'),
(5, 'order_609e477f1e2d8', 9, 5, 'Ab voluptas possimus', 4, '2019-10-26', '22:36:00', 'Doloremque quia aliq', 'Pending', '2021-05-14 14:48:52', '2021-05-14 14:48:52'),
(6, 'order_609e4f300a662', 10, 4, 'Ut ipsam doloribus p', 15, '1980-04-22', '21:32:00', 'Recusandae Suscipit', 'Pending', '2021-05-14 15:21:40', '2021-05-14 15:21:40'),
(7, 'order_609e531111a4a', 11, 2, 'Inventore omnis volu', 90, '1998-09-23', '09:59:00', 'Harum aspernatur eaq', 'In progress', '2021-05-14 15:38:18', '2021-05-14 15:38:18'),
(8, 'order_609e54a2482fd', 12, 5, 'Ad perspiciatis ame', 83, '2001-06-08', '03:56:00', 'Officia aperiam aspe', 'Pending', '2021-05-14 15:44:55', '2021-05-14 15:44:55'),
(9, 'order_609e55afa5090', 13, 3, 'Enim minus consequat', 11, '2015-09-26', '10:39:00', 'Nobis rerum nostrud ', 'In progress', '2021-05-14 15:49:24', '2021-05-14 15:49:24'),
(10, 'order_609f389061ac3', 14, 4, 'Libero fuga Amet q', 94, '1993-04-01', '05:00:00', 'Sequi ut irure non d', 'Pending', '2021-05-15 07:58:00', '2021-05-15 07:58:00'),
(11, 'order_609f389061qc3', 14, 4, 'Hmmbh JH ji ', 2, '2021-05-19', '05:00:00', 'H) (oij o Jnuh h99u98umk nioj o okjnoi9m iojji 8u iojinu jhoiou9...', 'Complete', '2021-05-03 20:23:04', '2021-05-16 20:23:06'),
(13, 'order_609f389061wc4', 14, 4, 'DUHA BYGBY ', 4, '2021-05-16', '06:00:00', 'PUGB &8yiuh 7y jokjhn98bbyn oiuhn9h7y  biuh7y  sdgwgb...', 'In progress', '2021-05-16 20:27:44', '2021-05-16 20:27:46'),
(14, 'order_609f389051wc5', 14, 2, 'HIUH   KHBJbg ', 3, '2021-05-03', '07:00:00', 'JHIUOHOu mnb ugoy  nkjhbboiu  nbg yg 87 NKbug78y  JHii ....', 'Pending', '2021-05-16 21:40:54', '2021-05-16 21:40:56'),
(15, 'order_60a3f79d6ed0f', 14, 4, 'AI with Blockchain', 6, '2021-05-18', '21:20:00', 'Laravel Jetstream automatically scaffolds the login, two-factor login, registration, password reset, and email verification features for your project, allowing you to start building the features you care about instead of worrying about the nitty-gritty details of user authentication.', 'In progress', '2021-05-18 22:21:52', '2021-05-23 12:28:27'),
(16, 'order_60a40466c41d9', 14, 5, 'Tesla Vehicles In Kenya', 5, '2021-05-26', '21:12:00', 'Laravel Jetstream automatically scaffolds the login, two-factor login, registration, password reset, and email verification features for your project, allowing you to start building the features you care about instead of worrying about the nitty-gritty details of user authentication.', 'In progress', '2021-05-18 23:17:07', '2021-05-23 12:42:35'),
(17, 'order_60a7eb2fe0288', 15, 2, 'Food Production Rate in the last 5years ', 5, '2021-05-22', '20:20:00', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available. Wikipedia', 'Pending', '2021-05-21 22:18:12', '2021-05-21 22:18:12'),
(18, 'order_60aa3fcce87a0', 16, 1, 'Road Works', 6, '2021-05-23', '14:42:00', 'Nine out of ten doctors recommend Laracasts over competing brands. Come inside, see for yourself, and massively level up your development skills in the process.', 'Pending', '2021-05-23 16:44:13', '2021-05-23 16:44:13'),
(19, 'order_60aab48fc72c2', 14, 3, 'Topic A', 2, '2021-05-23', '01:00:00', 'JH 8 ,jh uih 7 ojqhf uwh gw ', 'Pending', '2021-05-24 01:01:47', '2021-05-24 01:01:47'),
(20, 'order_60aab70f76672', 14, 5, 'SSSAA', 2, '2021-05-20', '23:11:00', 'BOG I jh uh9uo hJH J I', 'Pending', '2021-05-24 01:12:15', '2021-05-24 01:12:15'),
(21, 'order_60aab979d92fb', 14, 4, 'Calculus', 4, '2021-05-17', '00:00:00', 'When using the local driver, public visibility translates to 0755 permissions for directories and 0644 permissions for files. You can modify the permissions mappings in your application\'s filesystems configuration file:', 'Pending', '2021-05-24 01:22:33', '2021-05-25 17:16:52'),
(22, 'order_60ad2f973cd53', 17, 2, 'Agric Economics', 5, '2021-08-04', '20:00:00', 'ABSTRACT The purpose of this study was to assess and evaluate the potential impact and implications of Economic Partnership Agreement (EPA) between Sudan and the European Union (EU) on the performance of its agricultural trade. The study depended on secondary data obtained from the Ministry of Agriculture and Forestry, Department of EPA, Ministry of Foreign Trade, Central Bank of the Sudan, Statistics Directorate and other relevant sources. The Armington model was used to estimate the Gulon...', 'In progress', '2021-05-25 22:11:21', '2021-06-01 19:34:16'),
(23, 'order_60ad371c29b21', 18, 5, 'Agricultural Economics', 6, '2021-05-25', '02:00:00', 'ABSTRACT The purpose of this study was to assess and evaluate the potential impact and implications of the Economic Partnership Agreement (EPA) between Sudan and the European Union (EU) on the performance of its agricultural trade. The study depended on secondary data obtained from the Ministry of Agriculture and Forestry, Department of EPA, Ministry of Foreign Trade, Central Bank of Sudan, Statistics Directorate, and other relevant sources. The Armington model was used to estimate the...', 'In progress', '2021-05-25 22:44:19', '2021-05-25 22:58:00'),
(24, 'order_60b5c250cb450', 17, 3, 'Balance Sheet', 10, '2021-06-02', '08:00:00', 'In this example, I will explain how to calculate time difference between two dates in hours and minutes in laravel,we will show calculate time difference between two dates in hours and minutes.we will carbon using time difference between two dates in hours and minutes.', 'Complete', '2021-06-01 10:15:30', '2021-06-01 10:33:11'),
(25, 'order_60b66caa7425a', 19, 3, 'Kra return', 3, '2021-06-03', '20:30:00', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available. Wikipedia', 'Pending', '2021-06-01 22:23:00', '2021-06-01 22:23:00'),
(26, 'order_60b66fdbc5145', 20, 3, 'Topic X', 2, '2021-06-09', '10:00:00', 'Additionally\nadded FontAwesome light, duotone & svg support\nadded Datatables Scrollpane Plugin\nadded btn-app Color Variations\nenhance brand-link with pushmenu inside brand\nadded new Border Bottom only input style\nadded custom-control-input Color Variations\nadded custom-control-input-outline for checkbox & radio\nenhanced ControlSidebar plugin for multiple control-sidebars', 'Pending', '2021-06-01 22:36:03', '2021-06-01 22:36:03'),
(27, 'order_60b67ecc6ad34', 21, 2, 'Dest', 3, '2021-06-09', '13:38:00', 'sggkgkf', 'Pending', '2021-06-01 23:40:42', '2021-06-01 23:40:42');

-- --------------------------------------------------------

--
-- Table structure for table `order_billings`
--

CREATE TABLE `order_billings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `total_amount` double NOT NULL,
  `paid_amount` double NOT NULL DEFAULT '0',
  `prepared_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_billings`
--

INSERT INTO `order_billings` (`id`, `order_id`, `amount`, `total_amount`, `paid_amount`, `prepared_by`, `created_at`, `updated_at`) VALUES
(5, 15, 20, 120, 0, 1, '2021-05-23 12:28:26', '2021-05-23 12:28:26'),
(6, 16, 10, 50, 0, 1, '2021-05-23 12:42:34', '2021-05-23 12:42:34'),
(7, 23, 20, 120, 0, 1, '2021-05-25 22:55:59', '2021-05-25 22:55:59'),
(8, 11, 10, 40, 0, 1, '2021-05-28 05:40:41', '2021-05-28 05:40:43'),
(9, 22, 20, 100, 0, 1, '2021-05-30 19:50:08', '2021-05-30 19:50:08'),
(10, 24, 20, 200, 0, 1, '2021-06-01 10:19:39', '2021-06-01 10:19:39');

-- --------------------------------------------------------

--
-- Table structure for table `paper_categories`
--

CREATE TABLE `paper_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `paper_categories`
--

INSERT INTO `paper_categories` (`id`, `subject`, `created_at`, `updated_at`) VALUES
(1, 'Engineering', '2021-05-09 13:05:44', '2021-05-09 13:05:51'),
(2, 'Agriculture', '2021-05-09 13:06:05', '2021-05-09 13:06:07'),
(3, 'Accounting', '2021-05-09 13:06:15', '2021-05-09 13:06:17'),
(4, 'Computer Science', '2021-05-09 13:06:27', '2021-05-09 13:06:29'),
(5, 'Research', '2021-05-09 13:06:36', '2021-05-09 13:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rejected_orders`
--

CREATE TABLE `rejected_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_id` bigint(20) NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rejected_orders`
--

INSERT INTO `rejected_orders` (`id`, `order_id`, `comment`, `from`, `from_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 22, 'Did not follow format instructions', 'client', 17, 'Pending', '2021-05-31 11:27:28', '2021-05-31 11:27:28');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('3OV1VUubiENfkD2NAwynAaZWzsIJyV9WxzqZctU2', NULL, '102.68.79.172', 'Mozilla/5.0 (Linux; Android 11; CPH2217) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.88 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWG9yUVEyUElDRTg0MnMyWjNuZlJ4dW42cXNHY3dVenR3UW9URHpvUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93cml0ZXIubmFyaXBob250ZWNobm9sb2dpZXMuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1622966532),
('ad4Lm5vG6CVdEnVhGBAvXalDkyJEKEcataoy1c8g', NULL, '66.249.93.140', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEN5TWNrSmQwTHppMTl5aWVnTFpjb3ZhaHFjUjVwdDJjeDQ1WEtBciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93cml0ZXIubmFyaXBob250ZWNobm9sb2dpZXMuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1622910019),
('dirCNdQdZiwQiOiP8ulzNQXn9Fa2I1HpOgeLsm24', NULL, '102.68.79.172', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiaVpmSFhGbml1MWV5TDlaOUUwVm5MZmpBVUhpN0ltSXpmTFRSaGV2VCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly93cml0ZXIubmFyaXBob250ZWNobm9sb2dpZXMuY29tL29yZGVyIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czoxMjoiTG9nZ2VkQ2xpZW50IjthOjE6e2k6MDtpOjE3O31zOjQ6InZpZXciO3M6MTQ6ImRvbmUgcmV2aXNpb25zIjt9', 1622784225),
('HIybxTGGdFYDBiBDuwqu9gvvPAVKuHVaEwhay8ml', NULL, '196.250.209.97', 'Mozilla/5.0 (Linux; Android 10; SM-A205F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.210 Mobile Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidFk4d3JIcmVjamFlQUtWYzA4WnI1M2FMWWo3Rnl2QnZZQ1I3eUs1ayI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly93cml0ZXIubmFyaXBob250ZWNobm9sb2dpZXMuY29tL2NsaWVudC9sb2dpbiI7fXM6NDoidmlldyI7czo5OiJyZXZpc2lvbnMiO30=', 1622779607),
('RoVSBVZ7sG41pHfSq7mqIT7cb9qPTYBMmFHvTsaT', NULL, '65.155.30.101', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.71 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWpnSE9aV2FiVjZKTGVDWENzSWlFODRPUlcwZVZwZDY5aVZiQWt2QiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly93cml0ZXIubmFyaXBob250ZWNobm9sb2dpZXMuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1622937073),
('ubI9IlpRWEglFcsx17qT2aWGslpiXEBK3Di6MSEB', NULL, '102.68.79.172', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjVXZkxOdTBNWGxmUmFad3JTOXRNRVo5Ykl6ZHV3b0xVejViRlpMWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly93cml0ZXIubmFyaXBob250ZWNobm9sb2dpZXMuY29tL29yZGVyIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1622794268);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_team` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `user_id`, `name`, `personal_team`, `created_at`, `updated_at`) VALUES
(1, 1, 'Cleo\'s Team', 1, '2021-05-11 02:26:29', '2021-05-11 02:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `team_invitations`
--

CREATE TABLE `team_invitations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_user`
--

CREATE TABLE `team_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temporary_files`
--

CREATE TABLE `temporary_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `folder` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `temporary_files`
--

INSERT INTO `temporary_files` (`id`, `folder`, `filename`, `created_at`, `updated_at`) VALUES
(1, '609e30c94d1c9-1620979913', 'CLEO_RESUME.pdf', '2021-05-14 13:11:53', '2021-05-14 13:11:53'),
(2, '609e30ca3ac86-1620979914', 'cis-1.pdf', '2021-05-14 13:11:54', '2021-05-14 13:11:54'),
(3, '609e3dfed20e2-1620983294', 'Bro Index.txt', '2021-05-14 14:08:15', '2021-05-14 14:08:15'),
(4, '609e3e001813c-1620983296', 'Ambrose ID.pdf', '2021-05-14 14:08:16', '2021-05-14 14:08:16'),
(5, '609e419bd22a9-1620984219', 'CLEO_RESUME.pdf', '2021-05-14 14:23:40', '2021-05-14 14:23:40'),
(6, '609e419d23f4b-1620984221', 'cis-1.pdf', '2021-05-14 14:23:41', '2021-05-14 14:23:41'),
(7, '609e4594cc0ab-1620985236', 'UNIT-2.pdf', '2021-05-14 14:40:37', '2021-05-14 14:40:37'),
(8, '609e4778d0cca-1620985720', 'resitexam2021.pdf', '2021-05-14 14:48:40', '2021-05-14 14:48:40'),
(9, '609e4779c8586-1620985721', 'btree.pdf', '2021-05-14 14:48:41', '2021-05-14 14:48:41'),
(10, '609e4f2d0e7d5-1620987693', 'Post.php', '2021-05-14 15:21:33', '2021-05-14 15:21:33'),
(11, '609e4f2dc8c27-1620987693', 'SearchTrait.php', '2021-05-14 15:21:33', '2021-05-14 15:21:33'),
(12, '609e53069e7ee-1620988678', 'COMP 410 Exam (2).pdf', '2021-05-14 15:37:58', '2021-05-14 15:37:58'),
(13, '609e5307a57f7-1620988679', 'Academic Website.pdf', '2021-05-14 15:37:59', '2021-05-14 15:37:59'),
(14, '609e549bae99c-1620989083', 'resitexam2021.pdf', '2021-05-14 15:44:43', '2021-05-14 15:44:43'),
(15, '609e549cf3568-1620989084', 'btree.pdf', '2021-05-14 15:44:45', '2021-05-14 15:44:45'),
(19, '609f38e40e75b-1621047524', 'btree.pdf', '2021-05-15 07:58:44', '2021-05-15 07:58:44'),
(20, '60a3ef7ed999e-1621356414', 'triangle.txt', '2021-05-18 21:47:00', '2021-05-18 21:47:00'),
(21, '60a3f66c1ef7b-1621358188', 'WhatsApp Image 2021-04-13 at 22.00.02 (2).png', '2021-05-18 22:16:28', '2021-05-18 22:16:28'),
(22, '60a3f66d1425f-1621358189', 'Project Step 4 - Relational DB Design.docx', '2021-05-18 22:16:29', '2021-05-18 22:16:29'),
(29, '60aa3f74a928e-1621770100', 'IMG-20210521-WA0000.jpg', '2021-05-23 16:41:41', '2021-05-23 16:41:41'),
(30, '60aa3f75affc1-1621770101', 'cw1 (2).pdf', '2021-05-23 16:41:41', '2021-05-23 16:41:41'),
(33, '60aab48cbafad-1621800076', 'triangle.txt', '2021-05-24 01:01:16', '2021-05-24 01:01:16'),
(34, '60aab48dadf02-1621800077', 'IMG-20210521-WA0000.jpg', '2021-05-24 01:01:17', '2021-05-24 01:01:17'),
(35, '60aab70c8cdd1-1621800716', 'LayoutTrait.php', '2021-05-24 01:11:56', '2021-05-24 01:11:56'),
(36, '60aab70d5c551-1621800717', 'WhatsApp Image 2021-04-21 at 09.18.16.jpeg', '2021-05-24 01:11:57', '2021-05-24 01:11:57'),
(37, '60aab91d3a9a8-1621801245', 'PA1.pdf', '2021-05-24 01:20:45', '2021-05-24 01:20:45'),
(65, '60b66c8f6744c-1622568079', 'Sales Invoice 84022.pdf', '2021-06-01 22:21:19', '2021-06-01 22:21:19'),
(66, '60b66ca7bae84-1622568103', 'IMG-20210601-WA0011.jpg', '2021-06-01 22:21:43', '2021-06-01 22:21:43'),
(67, '60b66fd93a3e7-1622568921', 'IMG-20210521-WA0000 (1).jpg', '2021-06-01 22:35:21', '2021-06-01 22:35:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'Cleo', 'cleoctech@gmail.com', NULL, '$2y$10$alcyvpMyk0VyGN/xjXruUugI7tHlG6mVbAyjxA2hpII1XL5rFqmP6', NULL, NULL, NULL, 1, NULL, '2021-05-11 02:26:28', '2021-05-18 15:38:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accepted_orders`
--
ALTER TABLE `accepted_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `accepted_orders_order_id_foreign` (`order_id`);

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_email_unique` (`email`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_tos`
--
ALTER TABLE `message_tos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_tos_message_id_foreign` (`message_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orders_order_no_unique` (`order_no`),
  ADD KEY `orders_client_id_foreign` (`client_id`),
  ADD KEY `orders_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `order_billings`
--
ALTER TABLE `order_billings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_billings_order_id_foreign` (`order_id`),
  ADD KEY `order_billings_prepared_by_foreign` (`prepared_by`);

--
-- Indexes for table `paper_categories`
--
ALTER TABLE `paper_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`(191),`tokenable_id`);

--
-- Indexes for table `rejected_orders`
--
ALTER TABLE `rejected_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rejected_orders_order_id_foreign` (`order_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teams_user_id_index` (`user_id`);

--
-- Indexes for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_invitations_team_id_email_unique` (`team_id`,`email`);

--
-- Indexes for table `team_user`
--
ALTER TABLE `team_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `team_user_team_id_user_id_unique` (`team_id`,`user_id`);

--
-- Indexes for table `temporary_files`
--
ALTER TABLE `temporary_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accepted_orders`
--
ALTER TABLE `accepted_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `message_tos`
--
ALTER TABLE `message_tos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `order_billings`
--
ALTER TABLE `order_billings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `paper_categories`
--
ALTER TABLE `paper_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rejected_orders`
--
ALTER TABLE `rejected_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `team_invitations`
--
ALTER TABLE `team_invitations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team_user`
--
ALTER TABLE `team_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `temporary_files`
--
ALTER TABLE `temporary_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accepted_orders`
--
ALTER TABLE `accepted_orders`
  ADD CONSTRAINT `accepted_orders_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `message_tos`
--
ALTER TABLE `message_tos`
  ADD CONSTRAINT `message_tos_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  ADD CONSTRAINT `orders_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `paper_categories` (`id`);

--
-- Constraints for table `order_billings`
--
ALTER TABLE `order_billings`
  ADD CONSTRAINT `order_billings_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_billings_prepared_by_foreign` FOREIGN KEY (`prepared_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `rejected_orders`
--
ALTER TABLE `rejected_orders`
  ADD CONSTRAINT `rejected_orders_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD CONSTRAINT `team_invitations_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
