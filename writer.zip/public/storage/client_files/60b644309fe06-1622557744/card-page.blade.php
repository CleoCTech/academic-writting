{{-- <turbo-stream target="crud" action="replace"  wire:loading.remove>
    <template> --}}
        <div>
        <form wire:submit.prevent="store">
            @csrf
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-1 items-center">
                @foreach($cols as $key => $col)
                    @if(($col['isCreate'] || $col['isEdit'] || $col['isView'] && $isView))
                        <div class="{{$col['element'] == 'textarea'?'col-span-3':''}}">
                            <label class=" text-gray-700 text-xs mb-2">{{$col['colCaption']}}</label>
                            @if($col['element'] == 'input')
                                @if($isView && $col['type'] != 'file' || $isCreate || $isEdit)
                                    <input id="{{$col['colName']}}" type="{{$col['type']}}" wire:model="{{isset($col['fileName'])? $col['fileName']:$col['colName']}}" id="{{isset($col['fileName'])? $col['fileName']:$col['colName']}}" placeholder="{{isset($col['placeholder']) ? $col['placeholder']:''}}" {{$isView || $col['isEdit'] == false? 'disabled':''}} accept="{{isset($col['accept'])? $col['accept']:''}}" {{isset($col['isRequired']) && $col['isRequired']? 'required':''}} class="shadow appearance-none border w-full py-2 px-3 leading-tight focus:outline-none focus:shadow-outline disabled:opacity-40 @error($col['colName']) border-red-600 @enderror">
                                    @if($col['type'] == 'file')
                                        <img src="/storage/general/small-load-black.gif" class="max-w-4 max-h-4 ml-2" wire:loading wire:target='{{$col['fileName']}}'>
                                    @endif
                                    @if((isset($col['isImage']) && $col['isImage'] == true && ${$col['fileName']} != null && (!$isEdit  || $isEdit && ${$col['fileName']} !== null)))
                                        Preview:
                                        <img src="@php echo ${$col['fileName']}->temporaryUrl() @endphp" class="max-w-20 max-h-20">
                                    @endif
                                @endif
                                @if(!$isCreate && $col['type'] == 'file')
                                    @if($col['isImage'] && ${$col['fileName']} == null)
                                        <img src="@php echo config('app.storagePaths')[$col['storageName']]['readPath'].${$col['colName']};@endphp" class="max-h-20 max-w-20">
                                    @endif
                                @endif
                            @elseif($col['element'] == 'textarea')
                                <textarea id="{{$col['colName']}}" class="shadow appearance-none border w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline disabled:opacity-40 @error($col['colName']) border-red-600 @enderror" placeholder="{{isset($col['placeholder']) ? $col['placeholder']:''}}" wire:model="{{$col['colName']}}" {{$isView || $col['isEdit'] == false? 'disabled':''}} {{isset($col['isRequired']) && $col['isRequired']? 'required':''}}></textarea>
                            @elseif($col['element'] == 'select')
                                <select id="{{$col['colName']}}" class="shadow appearance-none border w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline disabled:opacity-40 @error($col['colName']) border-red-600 @enderror" {{$isView || $col['isEdit'] == false? 'disabled':''}} wire:model="{{$col['colName']}}" {{$col['isMultiple']? 'multiple size='.count($col["options"]).'':''}} {{isset($col['isRequired']) && $col['isRequired']? 'required':''}}>
                                    <option value="">--select--</option>
                                    @foreach($col['options'] as $option)
                                        <option value="{{$option['id']}}" @php echo !$isCreate && ${$col['colName']} == $option['id']? 'selected':'';@endphp>{{$option['description']}}</option>
                                    @endforeach
                                </select>
                            @elseif($col['element'] == 'checkbox')
                                <input id="{{$col['colName']}}" type="checkbox" class="shadow appearance-none border w-4 h-4 leading-tight focus:outline-none focus:shadow-outline disabled:opacity-40 rounded-lg @error($col['colName']) border-red-600 @enderror" wire:model="{{$col['colName']}}" @php echo ${$col['colName']} == 1? 'checked':'';@endphp {{$isView || $col['isEdit'] == false? 'disabled':''}} {{isset($col['isRequired']) && $col['isRequired']? 'required':''}}>
                            @endif
                        </div>
                    @endif
                @endforeach
            </div>
            @if($isCreate || $isEdit)
            <div class="mt-5 flex justify-center items-center">
                <button type="submit" wire:loading.remove wire:target='photoFile' class="bg-green-500 px-3 py-2 flex items-center text-sm text-white text-center disabled:opacity-40"><x-heroicon-o-check class="pl-0"/> Save</button>
            </div>
            @endif
            </form>
        </div>
    {{-- </template>
  </turbo-stream> --}}
