<?php

namespace App\Http\Livewire\Admin\Inc;

use Livewire\Component;

class ScrollTop extends Component
{
    public function render()
    {
        return view('livewire.admin.inc.scroll-top');
    }
}
