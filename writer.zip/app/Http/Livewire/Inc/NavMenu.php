<?php

namespace App\Http\Livewire\Inc;

use Livewire\Component;

class NavMenu extends Component
{


    public function render()
    {
        return view('livewire.inc.nav-menu');
    }
}
