<?php

namespace App\Http\Livewire\General;

use Livewire\Component;

class Loader extends Component
{
    public function render()
    {
        return view('livewire.general.loader');
    }
}
